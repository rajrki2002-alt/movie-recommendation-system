import { useState, useEffect } from 'react';
import { Review } from '../types/movie';
import { fetchMovieReviews, getAvatarUrl } from '../services/movieService';

interface FeaturedReviewsProps {
  movieIds: number[];
}

export default function FeaturedReviews({ movieIds }: FeaturedReviewsProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFeaturedReviews();
  }, [movieIds]);

  const loadFeaturedReviews = async () => {
    setLoading(true);
    const allReviews: Review[] = [];
    
    // Fetch reviews from first 3 movies
    for (const movieId of movieIds.slice(0, 3)) {
      const movieReviews = await fetchMovieReviews(movieId);
      if (movieReviews.length > 0) {
        // Get the most helpful review (one with rating if available)
        const bestReview = movieReviews.find(r => r.author_details.rating) || movieReviews[0];
        allReviews.push(bestReview);
      }
    }
    
    setReviews(allReviews.slice(0, 3));
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex h-32 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-gray-700 border-t-blue-500"></div>
      </div>
    );
  }

  if (reviews.length === 0) return null;

  const getRatingColor = (rating: number | null) => {
    if (!rating) return 'bg-gray-500';
    if (rating >= 8) return 'bg-green-500';
    if (rating >= 6) return 'bg-blue-500';
    if (rating >= 4) return 'bg-yellow-500';
    return 'bg-orange-500';
  };

  return (
    <div className="mb-12">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white">Featured Reviews</h2>
        <p className="text-gray-400">What users are saying about top movies</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {reviews.map((review) => (
          <div key={review.id} className="rounded-xl bg-gray-800/50 p-6 backdrop-blur-sm">
            {/* Author */}
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={getAvatarUrl(review.author_details.avatar_path)}
                  alt={review.author}
                  className="h-10 w-10 rounded-full bg-gray-700 object-cover"
                  onError={(e) => {
                    e.currentTarget.src = 'https://via.placeholder.com/100/1f2937/ffffff?text=' + review.author.charAt(0).toUpperCase();
                  }}
                />
                <div>
                  <h4 className="text-sm font-semibold text-white">
                    {review.author_details.name || review.author}
                  </h4>
                  <p className="text-xs text-gray-400">@{review.author_details.username}</p>
                </div>
              </div>

              {review.author_details.rating && (
                <div className={`flex items-center gap-1 rounded-full ${getRatingColor(review.author_details.rating)} px-2 py-1 text-xs font-semibold text-white`}>
                  <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                  {review.author_details.rating.toFixed(1)}
                </div>
              )}
            </div>

            {/* Review excerpt */}
            <p className="line-clamp-4 text-sm leading-relaxed text-gray-300">
              {review.content}
            </p>

            {/* Date */}
            <div className="mt-4 text-xs text-gray-500">
              {new Date(review.created_at).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
