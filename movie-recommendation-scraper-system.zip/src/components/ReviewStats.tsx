interface ReviewStatsProps {
  reviewCount: number;
  averageRating?: number;
}

export default function ReviewStats({ reviewCount, averageRating }: ReviewStatsProps) {
  if (reviewCount === 0) return null;

  return (
    <div className="mt-2 flex items-center gap-2 text-xs text-gray-400">
      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
      </svg>
      <span>{reviewCount} {reviewCount === 1 ? 'review' : 'reviews'}</span>
      {averageRating && averageRating > 0 && (
        <span className="ml-1">• Avg: {averageRating.toFixed(1)}/10</span>
      )}
    </div>
  );
}
