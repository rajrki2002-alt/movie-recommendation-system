import { useState, useEffect } from 'react';
import { Movie, Review } from '../types/movie';
import { getImageUrl, fetchMovieReviews } from '../services/movieService';
import ReviewCard from './ReviewCard';

interface MovieModalProps {
  movie: Movie | null;
  onClose: () => void;
}

export default function MovieModal({ movie, onClose }: MovieModalProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'reviews'>('overview');

  useEffect(() => {
    if (movie) {
      loadReviews();
    }
  }, [movie]);

  const loadReviews = async () => {
    if (!movie) return;
    setLoadingReviews(true);
    const movieReviews = await fetchMovieReviews(movie.id);
    setReviews(movieReviews);
    setLoadingReviews(false);
  };

  if (!movie) return null;

  const getRatingColor = (rating: number) => {
    if (rating >= 8) return 'text-green-400';
    if (rating >= 7) return 'text-blue-400';
    if (rating >= 6) return 'text-yellow-400';
    return 'text-orange-400';
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="relative max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-2xl bg-gray-900 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-black/50 text-white backdrop-blur-sm transition-colors hover:bg-black/70"
        >
          <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Backdrop image */}
        <div className="relative h-96 overflow-hidden">
          <img
            src={getImageUrl(movie.backdrop_path || movie.poster_path, 'original')}
            alt={movie.title}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent"></div>
        </div>

        {/* Content */}
        <div className="relative -mt-32 px-8 pb-8">
          <div className="flex flex-col gap-6 md:flex-row">
            {/* Poster */}
            <div className="flex-shrink-0">
              <img
                src={getImageUrl(movie.poster_path)}
                alt={movie.title}
                className="w-48 rounded-lg shadow-2xl"
              />
            </div>

            {/* Details */}
            <div className="flex-1 text-white">
              <h2 className="mb-2 text-4xl font-bold">{movie.title}</h2>
              
              {movie.release_date && (
                <p className="mb-4 text-gray-400">
                  {new Date(movie.release_date).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </p>
              )}

              {/* Rating */}
              <div className="mb-6 flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <div className={`flex items-center gap-1 text-3xl font-bold ${getRatingColor(movie.vote_average)}`}>
                    <svg className="h-8 w-8" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                    {movie.vote_average.toFixed(1)}
                  </div>
                  <span className="text-gray-400">/ 10</span>
                </div>
                
                <div className="text-sm text-gray-400">
                  <span className="font-semibold">{movie.vote_count.toLocaleString()}</span> votes
                </div>

                <div className="text-sm text-gray-400">
                  Popularity: <span className="font-semibold">{Math.round(movie.popularity)}</span>
                </div>
              </div>

              {/* Recommendation badge */}
              {movie.vote_average >= 8 && (
                <div className="mb-4 inline-block rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 px-4 py-2 text-sm font-bold text-white shadow-lg">
                  ⭐ Highly Recommended
                </div>
              )}

              {/* Tabs */}
              <div className="mb-6 flex gap-4 border-b border-gray-700">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`pb-3 text-sm font-semibold transition-colors ${
                    activeTab === 'overview'
                      ? 'border-b-2 border-blue-500 text-white'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Overview
                </button>
                <button
                  onClick={() => setActiveTab('reviews')}
                  className={`pb-3 text-sm font-semibold transition-colors ${
                    activeTab === 'reviews'
                      ? 'border-b-2 border-blue-500 text-white'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Reviews ({reviews.length})
                </button>
              </div>

              {/* Overview Tab */}
              {activeTab === 'overview' && (
                <>
                  <div className="mb-6">
                    <h3 className="mb-2 text-xl font-semibold">Overview</h3>
                    <p className="leading-relaxed text-gray-300">{movie.overview || 'No overview available.'}</p>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-4 rounded-lg bg-gray-800/50 p-4">
                    <div>
                      <p className="text-sm text-gray-400">Language</p>
                      <p className="font-semibold uppercase">{movie.original_language}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-400">Rating Score</p>
                      <p className="font-semibold">
                        {movie.vote_average >= 8 ? 'Excellent' : 
                         movie.vote_average >= 7 ? 'Great' : 
                         movie.vote_average >= 6 ? 'Good' : 'Fair'}
                      </p>
                    </div>
                  </div>
                </>
              )}

              {/* Reviews Tab */}
              {activeTab === 'reviews' && (
                <div className="space-y-4">
                  {loadingReviews ? (
                    <div className="flex h-32 items-center justify-center">
                      <div className="h-8 w-8 animate-spin rounded-full border-4 border-gray-700 border-t-blue-500"></div>
                    </div>
                  ) : reviews.length > 0 ? (
                    <>
                      <div className="mb-4">
                        <h3 className="text-xl font-semibold">User Reviews</h3>
                        <p className="text-sm text-gray-400">{reviews.length} {reviews.length === 1 ? 'review' : 'reviews'} from TMDB users</p>
                      </div>
                      <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
                        {reviews.map((review) => (
                          <ReviewCard key={review.id} review={review} />
                        ))}
                      </div>
                    </>
                  ) : (
                    <div className="flex h-32 flex-col items-center justify-center text-gray-400">
                      <svg className="mb-2 h-12 w-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
                      </svg>
                      <p className="font-semibold">No reviews yet</p>
                      <p className="text-sm">Be the first to review this movie on TMDB</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
