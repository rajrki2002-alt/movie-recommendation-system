import { Movie } from '../types/movie';
import { getImageUrl } from '../services/movieService';

interface MovieCardProps {
  movie: Movie;
  onClick: (movie: Movie) => void;
}

export default function MovieCard({ movie, onClick }: MovieCardProps) {
  const getRatingColor = (rating: number) => {
    if (rating >= 8) return 'bg-green-500';
    if (rating >= 7) return 'bg-blue-500';
    if (rating >= 6) return 'bg-yellow-500';
    return 'bg-orange-500';
  };

  const getRatingLabel = (rating: number) => {
    if (rating >= 8) return 'Excellent';
    if (rating >= 7) return 'Great';
    if (rating >= 6) return 'Good';
    return 'Fair';
  };

  return (
    <div
      onClick={() => onClick(movie)}
      className="group relative cursor-pointer overflow-hidden rounded-xl bg-gray-900 shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-2xl"
    >
      <div className="aspect-[2/3] overflow-hidden">
        <img
          src={getImageUrl(movie.poster_path)}
          alt={movie.title}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
        />
      </div>
      
      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-80"></div>
      
      {/* Content */}
      <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
        <h3 className="mb-2 text-lg font-bold line-clamp-2">{movie.title}</h3>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className={`flex items-center gap-1 rounded-full ${getRatingColor(movie.vote_average)} px-2 py-1 text-xs font-semibold`}>
              <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
              {movie.vote_average.toFixed(1)}
            </div>
            <span className="text-xs text-gray-300">{getRatingLabel(movie.vote_average)}</span>
          </div>
          
          {movie.release_date && (
            <span className="text-xs text-gray-400">
              {new Date(movie.release_date).getFullYear()}
            </span>
          )}
        </div>
        
        <div className="mt-2 text-xs text-gray-400">
          {movie.vote_count.toLocaleString()} votes
        </div>
      </div>

      {/* Recommended badge */}
      {movie.vote_average >= 8 && (
        <div className="absolute right-2 top-2 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 px-3 py-1 text-xs font-bold text-white shadow-lg">
          ⭐ Recommended
        </div>
      )}
    </div>
  );
}
