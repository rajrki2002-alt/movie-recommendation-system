import { useState } from 'react';
import { Review } from '../types/movie';
import { getAvatarUrl } from '../services/movieService';

interface ReviewCardProps {
  review: Review;
}

export default function ReviewCard({ review }: ReviewCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const maxLength = 300;
  const shouldTruncate = review.content.length > maxLength;
  const displayContent = isExpanded ? review.content : review.content.slice(0, maxLength);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getRatingColor = (rating: number | null) => {
    if (!rating) return 'bg-gray-500';
    if (rating >= 8) return 'bg-green-500';
    if (rating >= 6) return 'bg-blue-500';
    if (rating >= 4) return 'bg-yellow-500';
    return 'bg-orange-500';
  };

  return (
    <div className="rounded-lg bg-gray-800/50 p-6 backdrop-blur-sm">
      {/* Author Info */}
      <div className="mb-4 flex items-start justify-between">
        <div className="flex items-center gap-3">
          <img
            src={getAvatarUrl(review.author_details.avatar_path)}
            alt={review.author}
            className="h-12 w-12 rounded-full bg-gray-700 object-cover"
            onError={(e) => {
              e.currentTarget.src = 'https://via.placeholder.com/100/1f2937/ffffff?text=' + review.author.charAt(0).toUpperCase();
            }}
          />
          <div>
            <h4 className="font-semibold text-white">
              {review.author_details.name || review.author}
            </h4>
            <p className="text-sm text-gray-400">@{review.author_details.username}</p>
          </div>
        </div>

        {/* Rating */}
        {review.author_details.rating && (
          <div className={`flex items-center gap-1 rounded-full ${getRatingColor(review.author_details.rating)} px-3 py-1 text-sm font-semibold text-white`}>
            <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
            {review.author_details.rating.toFixed(1)}
          </div>
        )}
      </div>

      {/* Review Content */}
      <div className="mb-3">
        <p className="text-gray-300 leading-relaxed whitespace-pre-line">
          {displayContent}
          {shouldTruncate && !isExpanded && '...'}
        </p>
        {shouldTruncate && (
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="mt-2 text-sm font-semibold text-blue-400 hover:text-blue-300"
          >
            {isExpanded ? 'Show Less' : 'Read More'}
          </button>
        )}
      </div>

      {/* Date */}
      <div className="flex items-center gap-2 text-xs text-gray-500">
        <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
        <span>Posted on {formatDate(review.created_at)}</span>
        {review.created_at !== review.updated_at && (
          <span className="italic">(edited)</span>
        )}
      </div>
    </div>
  );
}
