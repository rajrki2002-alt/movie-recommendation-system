import { Genre } from '../types/movie';

interface FilterBarProps {
  genres: Genre[];
  selectedGenre: string;
  minRating: number;
  sortBy: string;
  onGenreChange: (genre: string) => void;
  onRatingChange: (rating: number) => void;
  onSortChange: (sort: string) => void;
}

export default function FilterBar({
  genres,
  selectedGenre,
  minRating,
  sortBy,
  onGenreChange,
  onRatingChange,
  onSortChange
}: FilterBarProps) {
  return (
    <div className="mb-8 flex flex-wrap gap-4 rounded-xl bg-gray-800/50 p-6 backdrop-blur-sm">
      {/* Genre Filter */}
      <div className="flex-1 min-w-[200px]">
        <label className="mb-2 block text-sm font-semibold text-gray-300">Genre</label>
        <select
          value={selectedGenre}
          onChange={(e) => onGenreChange(e.target.value)}
          className="w-full rounded-lg border border-gray-600 bg-gray-700 px-4 py-2 text-white focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">All Genres</option>
          {genres.map((genre) => (
            <option key={genre.id} value={genre.id}>
              {genre.name}
            </option>
          ))}
        </select>
      </div>

      {/* Rating Filter */}
      <div className="flex-1 min-w-[200px]">
        <label className="mb-2 block text-sm font-semibold text-gray-300">
          Minimum Rating: {minRating.toFixed(1)}
        </label>
        <input
          type="range"
          min="0"
          max="10"
          step="0.5"
          value={minRating}
          onChange={(e) => onRatingChange(parseFloat(e.target.value))}
          className="w-full accent-blue-500"
        />
        <div className="mt-1 flex justify-between text-xs text-gray-400">
          <span>0</span>
          <span>5</span>
          <span>10</span>
        </div>
      </div>

      {/* Sort By */}
      <div className="flex-1 min-w-[200px]">
        <label className="mb-2 block text-sm font-semibold text-gray-300">Sort By</label>
        <select
          value={sortBy}
          onChange={(e) => onSortChange(e.target.value)}
          className="w-full rounded-lg border border-gray-600 bg-gray-700 px-4 py-2 text-white focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="rating">Highest Rated</option>
          <option value="popularity">Most Popular</option>
          <option value="release_date">Release Date</option>
        </select>
      </div>
    </div>
  );
}
