import { useState, useEffect } from 'react';
import { Movie, Genre } from './types/movie';
import {
  fetchPopularMovies,
  fetchTopRatedMovies,
  fetchTrendingMovies,
  fetchGenres,
  searchMovies,
  fetchMoviesByGenre,
  getRecommendedMovies
} from './services/movieService';
import MovieCard from './components/MovieCard';
import MovieModal from './components/MovieModal';
import FilterBar from './components/FilterBar';
import FeaturedReviews from './components/FeaturedReviews';

export default function App() {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [allMovies, setAllMovies] = useState<Movie[]>([]);
  const [genres, setGenres] = useState<Genre[]>([]);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'popular' | 'top_rated' | 'trending' | 'recommended'>('recommended');
  
  // Filters
  const [selectedGenre, setSelectedGenre] = useState('');
  const [minRating, setMinRating] = useState(0);
  const [sortBy, setSortBy] = useState('rating');

  useEffect(() => {
    loadInitialData();
  }, []);

  useEffect(() => {
    loadMovies();
  }, [activeTab, selectedGenre]);

  useEffect(() => {
    applyFilters();
  }, [allMovies, minRating, sortBy]);

  const loadInitialData = async () => {
    setLoading(true);
    const [genresData] = await Promise.all([
      fetchGenres()
    ]);
    setGenres(genresData);
    await loadMovies();
    setLoading(false);
  };

  const loadMovies = async () => {
    setLoading(true);
    let fetchedMovies: Movie[] = [];

    if (selectedGenre) {
      fetchedMovies = await fetchMoviesByGenre(Number(selectedGenre));
    } else {
      switch (activeTab) {
        case 'popular':
          fetchedMovies = await fetchPopularMovies();
          break;
        case 'top_rated':
          fetchedMovies = await fetchTopRatedMovies();
          break;
        case 'trending':
          fetchedMovies = await fetchTrendingMovies();
          break;
        case 'recommended':
          const popular = await fetchPopularMovies();
          const topRated = await fetchTopRatedMovies();
          const combined = [...popular, ...topRated];
          fetchedMovies = getRecommendedMovies(combined, 7.0);
          break;
      }
    }

    setAllMovies(fetchedMovies);
    setLoading(false);
  };

  const applyFilters = () => {
    let filtered = [...allMovies];

    // Filter by minimum rating
    filtered = filtered.filter(movie => movie.vote_average >= minRating);

    // Sort
    switch (sortBy) {
      case 'rating':
        filtered.sort((a, b) => b.vote_average - a.vote_average);
        break;
      case 'popularity':
        filtered.sort((a, b) => b.popularity - a.popularity);
        break;
      case 'release_date':
        filtered.sort((a, b) => new Date(b.release_date).getTime() - new Date(a.release_date).getTime());
        break;
    }

    setMovies(filtered);
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLoading(true);
      const results = await searchMovies(searchQuery);
      setAllMovies(results);
      setLoading(false);
    }
  };

  const clearSearch = () => {
    setSearchQuery('');
    loadMovies();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <header className="border-b border-gray-700 bg-gray-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="mb-6 flex flex-col items-center justify-between gap-4 md:flex-row">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg">
                <svg className="h-7 w-7 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 00.553.894l2 1A1 1 0 0018 13V7a1 1 0 00-1.447-.894l-2 1z" />
                </svg>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">CineMatch</h1>
                <p className="text-sm text-gray-400">Your Movie Recommendation System</p>
              </div>
            </div>

            {/* Search */}
            <form onSubmit={handleSearch} className="w-full max-w-md">
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search for movies..."
                  className="w-full rounded-lg border border-gray-600 bg-gray-800 px-4 py-2 pl-10 text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <svg
                  className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
                {searchQuery && (
                  <button
                    type="button"
                    onClick={clearSearch}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                  >
                    ✕
                  </button>
                )}
              </div>
            </form>
          </div>

          {/* Tabs */}
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'recommended', label: '⭐ Recommended', icon: '⭐' },
              { id: 'top_rated', label: 'Top Rated', icon: '🏆' },
              { id: 'popular', label: 'Popular', icon: '🔥' },
              { id: 'trending', label: 'Trending', icon: '📈' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`rounded-lg px-4 py-2 font-semibold transition-all ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Filters */}
        <FilterBar
          genres={genres}
          selectedGenre={selectedGenre}
          minRating={minRating}
          sortBy={sortBy}
          onGenreChange={setSelectedGenre}
          onRatingChange={setMinRating}
          onSortChange={setSortBy}
        />

        {/* Featured Reviews - Only show on recommended tab */}
        {activeTab === 'recommended' && !searchQuery && !selectedGenre && movies.length > 0 && (
          <FeaturedReviews movieIds={movies.slice(0, 3).map(m => m.id)} />
        )}

        {/* Stats */}
        <div className="mb-6 flex items-center justify-between">
          <div className="text-white">
            <h2 className="text-2xl font-bold">
              {searchQuery ? `Search Results for "${searchQuery}"` : 
               selectedGenre ? `${genres.find(g => g.id.toString() === selectedGenre)?.name} Movies` :
               activeTab === 'recommended' ? 'Recommended Movies' :
               activeTab === 'top_rated' ? 'Top Rated Movies' :
               activeTab === 'popular' ? 'Popular Movies' :
               'Trending Movies'}
            </h2>
            <p className="text-gray-400">
              {movies.length} {movies.length === 1 ? 'movie' : 'movies'} found
            </p>
          </div>
        </div>

        {/* Loading */}
        {loading && (
          <div className="flex h-64 items-center justify-center">
            <div className="h-12 w-12 animate-spin rounded-full border-4 border-gray-700 border-t-blue-500"></div>
          </div>
        )}

        {/* Movies Grid */}
        {!loading && movies.length > 0 && (
          <div className="grid grid-cols-2 gap-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {movies.map((movie) => (
              <MovieCard
                key={movie.id}
                movie={movie}
                onClick={setSelectedMovie}
              />
            ))}
          </div>
        )}

        {/* No Results */}
        {!loading && movies.length === 0 && (
          <div className="flex h-64 flex-col items-center justify-center text-gray-400">
            <svg className="mb-4 h-16 w-16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z"
              />
            </svg>
            <p className="text-xl font-semibold">No movies found</p>
            <p className="text-sm">Try adjusting your filters or search query</p>
          </div>
        )}
      </main>

      {/* Movie Modal */}
      <MovieModal movie={selectedMovie} onClose={() => setSelectedMovie(null)} />

      {/* Footer */}
      <footer className="mt-16 border-t border-gray-700 bg-gray-900/50 py-6">
        <div className="container mx-auto px-4 text-center text-gray-400">
          <p className="text-sm">
            Movie data provided by{' '}
            <a
              href="https://www.themoviedb.org/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300"
            >
              The Movie Database (TMDB)
            </a>
          </p>
          <p className="mt-2 text-xs">
            This product uses the TMDB API but is not endorsed or certified by TMDB.
          </p>
        </div>
      </footer>
    </div>
  );
}
