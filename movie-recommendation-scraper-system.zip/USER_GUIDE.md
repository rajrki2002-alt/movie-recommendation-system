# 🎬 CineMatch - User Guide
## How to Use Your Movie Recommendation System

---

## 🏠 Homepage Overview

When you first open CineMatch, you'll see:

### Header Section
```
┌─────────────────────────────────────────────────────────┐
│  🎬 CineMatch                        [Search Movies...] │
│  Your Movie Recommendation System                       │
│                                                          │
│  [⭐Recommended] [🏆Top Rated] [🔥Popular] [📈Trending] │
└─────────────────────────────────────────────────────────┘
```

### Filter Bar
```
┌─────────────────────────────────────────────────────────┐
│  Genre: [All Genres ▼]  Rating: [━━●━━] 0.0  Sort: [▼] │
└─────────────────────────────────────────────────────────┘
```

### Featured Reviews (Only on Recommended Tab)
```
┌─────────────────────────────────────────────────────────┐
│  Featured Reviews                                        │
│  What users are saying about top movies                  │
│                                                          │
│  ┌──────┐ ┌──────┐ ┌──────┐                            │
│  │Review│ │Review│ │Review│                            │
│  │  #1  │ │  #2  │ │  #3  │                            │
│  └──────┘ └──────┘ └──────┘                            │
└─────────────────────────────────────────────────────────┘
```

### Movie Grid
```
┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐
│Movie │ │Movie │ │Movie │ │Movie │ │Movie │ │Movie │
│  #1  │ │  #2  │ │  #3  │ │  #4  │ │  #5  │ │  #6  │
│ ⭐8.5│ │ ⭐8.2│ │ ⭐7.9│ │ ⭐7.7│ │ ⭐7.5│ │ ⭐7.3│
└──────┘ └──────┘ └──────┘ └──────┘ └──────┘ └──────┘
```

---

## 🎯 Step-by-Step User Guide

### 1. Browse Movies

#### Default View: Recommended Movies
When you first arrive, you see:
- **10 highly-rated movies** (rating 7.0+)
- **Featured reviews** from top movies
- Movies are **sorted by rating** (highest first)

#### Switch Tabs
Click any tab to change the movie selection:
- **⭐ Recommended**: Best rated movies (7.0+)
- **🏆 Top Rated**: Highest-rated films of all time
- **🔥 Popular**: Currently most popular movies
- **📈 Trending**: Trending this week

---

### 2. Use Filters

#### Filter by Genre
```
Click: [Genre Dropdown]
Select: "Action" or "Comedy" or any genre
Result: Shows only movies from that genre
```

#### Set Minimum Rating
```
Drag: Rating slider
Range: 0.0 to 10.0
Example: Set to 8.0 to see only excellent movies
Result: Filters out movies below your threshold
```

#### Sort Results
```
Click: [Sort Dropdown]
Options:
  - Highest Rated (default)
  - Most Popular
  - Release Date (newest first)
Result: Re-orders movies by your selection
```

---

### 3. Search for Movies

```
┌─────────────────────────────────────┐
│  🔍 [Search for movies...]          │
└─────────────────────────────────────┘

Steps:
1. Click search bar
2. Type movie title (e.g., "Inception")
3. Press Enter
4. See instant results

To clear:
- Click the X button
- Returns to browsing mode
```

---

### 4. View Movie Details

#### Click Any Movie Card
When you click a movie, a modal opens showing:

```
┌─────────────────────────────────────────────────────────┐
│                    [Movie Backdrop]                   [×]│
│                                                          │
│  ┌────────┐                                             │
│  │ Poster │  Movie Title                                │
│  │        │  Released: January 15, 2024                 │
│  │        │  ⭐ 8.5 / 10                                │
│  └────────┘  1,234 votes  •  Popularity: 456           │
│                                                          │
│  ⭐ Highly Recommended                                  │
│                                                          │
│  [Overview] [Reviews (12)]                              │
│  ─────────                                              │
│                                                          │
│  Overview                                                │
│  This is the movie description and plot summary...       │
│                                                          │
│  Language: EN  •  Rating Score: Excellent               │
└─────────────────────────────────────────────────────────┘
```

---

### 5. Read Reviews

#### Switch to Reviews Tab
```
Click: [Reviews (12)]

You'll see:
┌─────────────────────────────────────────────────────────┐
│  User Reviews                                            │
│  12 reviews from TMDB users                              │
│                                                          │
│  ┌───────────────────────────────────────────────────┐  │
│  │ 👤 John Smith                          ⭐ 9.0    │  │
│  │    @johnsmith                                      │  │
│  │                                                    │  │
│  │    This movie was absolutely amazing! The         │  │
│  │    cinematography was stunning and...             │  │
│  │                                                    │  │
│  │    [Read More]                                     │  │
│  │                                                    │  │
│  │    📅 Posted on January 20, 2024                  │  │
│  └───────────────────────────────────────────────────┘  │
│                                                          │
│  ┌───────────────────────────────────────────────────┐  │
│  │ 👤 Jane Doe                            ⭐ 8.5    │  │
│  │    @janedoe                                        │  │
│  │    ...                                             │  │
│  └───────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

#### Read Full Reviews
- **Long reviews** are truncated
- Click **"Read More"** to expand
- Click **"Show Less"** to collapse

---

## 📱 Mobile Experience

On mobile devices, the layout automatically adjusts:

```
Mobile View:
┌──────────────┐
│   CineMatch  │
│ [Search...]  │
│              │
│ [Tabs...]    │
│              │
│ [Filters]    │
│              │
│ ┌──┐  ┌──┐  │
│ │M1│  │M2│  │  (2 columns)
│ └──┘  └──┘  │
│ ┌──┐  ┌──┐  │
│ │M3│  │M4│  │
│ └──┘  └──┘  │
└──────────────┘
```

---

## 🎨 Understanding the Ratings

### Color-Coded System

Every movie and review shows a color-coded rating:

```
🟢 GREEN (8.0-10.0)
   "EXCELLENT" or "Highly Recommended"
   These are must-watch movies!

🔵 BLUE (7.0-7.9)
   "GREAT" or "Recommended"
   High quality, worth your time

🟡 YELLOW (6.0-6.9)
   "GOOD" or "Worth Watching"
   Solid entertainment

🟠 ORANGE (5.0-5.9)
   "FAIR" or "Mixed Reviews"
   Might appeal to specific audiences
```

### Two Types of Ratings

1. **Movie Average Rating** (on movie card)
   - Average of all TMDB user votes
   - Number of votes shown below rating
   - Example: ⭐ 8.5 • 1,234 votes

2. **Individual Review Rating** (in reviews tab)
   - Personal rating from that specific reviewer
   - Not all reviews have ratings
   - Example: ⭐ 9.0 (John's rating)

---

## 🔍 Finding Movies You'll Love

### Method 1: Use Recommended Tab
```
1. Click "⭐ Recommended" tab
2. See top-rated movies (7.0+)
3. Browse featured reviews
4. Click movies that interest you
```

### Method 2: Filter by Genre
```
1. Select genre (e.g., "Sci-Fi")
2. Adjust rating slider (e.g., 7.5+)
3. Browse filtered results
4. Read reviews to decide
```

### Method 3: Search Specifically
```
1. Know a movie name? Search it!
2. Type in search bar
3. See instant results
4. Click to view details
```

### Method 4: Check What's Trending
```
1. Click "📈 Trending" tab
2. See this week's hot movies
3. Check ratings and reviews
4. Discover new releases
```

---

## 💡 Pro Tips

### Tip 1: Check Vote Count
```
High votes = More reliable rating
Example: 
  ⭐ 8.5 • 5,000 votes   ✅ Very reliable
  ⭐ 8.5 • 10 votes      ⚠️  Less reliable
```

### Tip 2: Read Multiple Reviews
```
Don't rely on one review!
- Check several opinions
- Look for common themes
- Balance positive and critical reviews
```

### Tip 3: Use Rating Slider
```
Want only the best?
- Set slider to 8.0+
- See only excellent movies
- Save time filtering
```

### Tip 4: Combine Filters
```
Want the best action movies?
1. Genre: "Action"
2. Rating: 7.5+
3. Sort: "Highest Rated"
Result: Best action films!
```

### Tip 5: Check Featured Reviews
```
On Recommended tab:
- See top 3 reviews
- Quick preview of opinions
- From highest-rated movies
- Helps make quick decisions
```

---

## 🎬 Common Use Cases

### "I want to watch something good tonight"
```
1. Go to "⭐ Recommended" tab
2. See top-rated movies
3. Read featured reviews
4. Pick one with 8.0+ rating
```

### "I'm in the mood for comedy"
```
1. Select Genre: "Comedy"
2. Set rating: 7.0+
3. Browse results
4. Check reviews
```

### "What's popular right now?"
```
1. Click "🔥 Popular" tab
2. See current favorites
3. Check ratings
4. Read what people say
```

### "I heard about [Movie Name]"
```
1. Type name in search
2. Click result
3. Read overview
4. Check reviews
```

### "Show me the best movies ever"
```
1. Click "🏆 Top Rated" tab
2. Set rating slider to 8.5+
3. Sorted by rating automatically
4. These are classics!
```

---

## 📊 Understanding Movie Information

### On Movie Cards:
- **Poster**: Visual preview
- **Title**: Movie name
- **Year**: Release year
- **Rating**: Average score with star
- **Badge**: Quality label
- **Votes**: Number of ratings
- **Recommended**: Badge if 8.0+

### In Movie Modal - Overview Tab:
- **Backdrop**: Large background image
- **Poster**: Movie poster (left side)
- **Title**: Full movie title
- **Release Date**: Exact date
- **Rating**: Large display with star
- **Vote Count**: Total votes
- **Popularity**: Trending score
- **Recommendation Badge**: If highly rated
- **Overview**: Full description
- **Language**: Original language
- **Rating Score**: Quality label

### In Movie Modal - Reviews Tab:
- **Review Count**: Total number of reviews
- **Individual Reviews**:
  - Reviewer avatar
  - Name and username
  - Personal rating (if given)
  - Full review text
  - Posted date
  - Edit indicator

---

## ❓ FAQs

### Q: Why don't all movies have reviews?
**A:** Not all movies on TMDB have user reviews yet. This is normal for newer or less popular films.

### Q: Can I write my own reviews?
**A:** This app displays reviews from TMDB. To write reviews, visit themoviedb.org and create an account there.

### Q: Are ratings from critics or users?
**A:** All ratings are from TMDB community users, not professional critics.

### Q: Why do some reviews not have ratings?
**A:** TMDB allows users to write reviews without giving a numeric rating. This is optional.

### Q: How often is data updated?
**A:** Every time you load the page, it fetches fresh data from TMDB. You always see current information!

### Q: Can I save favorite movies?
**A:** This feature isn't included yet, but you can bookmark the page and return anytime.

---

## 🎯 Quick Actions Reference

| I Want To... | Do This... |
|--------------|------------|
| See best movies | Click "Recommended" tab |
| Find comedy | Genre: "Comedy" |
| Only see excellent | Rating slider: 8.0+ |
| Search specific movie | Use search bar |
| See what's hot | Click "Trending" |
| Read opinions | Click movie → Reviews tab |
| See movie details | Click any movie card |
| Clear filters | Select "All Genres", set rating to 0 |
| Close movie details | Click X or outside modal |

---

## 🌟 Making the Most of CineMatch

### Best Practice Workflow:

1. **Start with Recommended**
   - See top-rated films
   - Check featured reviews
   - Get quick overview

2. **Apply Your Preferences**
   - Select favorite genre
   - Set quality threshold
   - Sort by preference

3. **Review Details**
   - Click interesting movies
   - Read full overview
   - Check multiple reviews

4. **Make Informed Decision**
   - Consider rating + votes
   - Read review content
   - Check release date

5. **Enjoy Your Movie!** 🎬🍿

---

## 🎊 Happy Movie Hunting!

You now know everything about using CineMatch!

**Remember:**
- 🟢 Green = Excellent (8.0+)
- 🔵 Blue = Great (7.0-7.9)
- Higher vote count = More reliable
- Read reviews for context
- Combine filters for precision

**Enjoy discovering amazing movies!** ✨

---

_Your personal movie recommendation assistant_ 🎬
