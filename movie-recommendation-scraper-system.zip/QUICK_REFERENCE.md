# 🚀 CineMatch - Quick Reference Guide

## 📦 Installation & Setup

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

---

## 📂 File Structure Reference

### Core Application Files
```
src/
├── App.tsx                      # Main app with state management
├── main.tsx                     # React entry point
└── index.css                    # Global styles
```

### Components (6 files)
```
src/components/
├── MovieCard.tsx                # Movie display card
├── MovieModal.tsx               # Movie details popup (with tabs)
├── ReviewCard.tsx               # Individual review display
├── FeaturedReviews.tsx          # Homepage review showcase
├── FilterBar.tsx                # Filter controls
└── ReviewStats.tsx              # Review statistics
```

### Services & Types
```
src/services/
└── movieService.ts              # All API calls to TMDB

src/types/
└── movie.ts                     # TypeScript interfaces
```

---

## 🎯 Key Functions (movieService.ts)

### Movie Data Functions
```typescript
fetchPopularMovies()             // Get popular movies
fetchTopRatedMovies()            // Get top-rated movies
fetchTrendingMovies()            // Get trending movies
fetchGenres()                    // Get all genres
searchMovies(query)              // Search by title
fetchMoviesByGenre(genreId)      // Filter by genre
getRecommendedMovies(movies)     // Apply recommendation algorithm
```

### Review Functions ⭐ NEW
```typescript
fetchMovieReviews(movieId)       // Get all reviews for a movie
```

### Helper Functions
```typescript
getImageUrl(path, size)          // Generate image URLs
getAvatarUrl(avatarPath)         // Generate avatar URLs
```

---

## 🎨 Component Props

### MovieCard
```typescript
{
  movie: Movie
  onClick: (movie: Movie) => void
}
```

### MovieModal
```typescript
{
  movie: Movie | null
  onClose: () => void
}
```

### ReviewCard
```typescript
{
  review: Review
}
```

### FeaturedReviews
```typescript
{
  movieIds: number[]
}
```

### FilterBar
```typescript
{
  genres: Genre[]
  selectedGenre: string
  minRating: number
  sortBy: string
  onGenreChange: (genre: string) => void
  onRatingChange: (rating: number) => void
  onSortChange: (sort: string) => void
}
```

---

## 🔧 State Management (App.tsx)

### Main State Variables
```typescript
movies                           // Currently displayed movies
allMovies                        // All fetched movies (before filtering)
genres                           // List of all genres
selectedMovie                    // Movie shown in modal
loading                          // Loading state
searchQuery                      // Search input value
activeTab                        // Current tab (recommended/popular/etc)
selectedGenre                    // Selected genre filter
minRating                        // Minimum rating filter
sortBy                           // Sort option
```

---

## 🎬 Movie Data Structure

```typescript
interface Movie {
  id: number                     // Unique movie ID
  title: string                  // Movie title
  overview: string               // Description
  poster_path: string | null     // Poster image path
  backdrop_path: string | null   // Backdrop image path
  release_date: string           // Release date (YYYY-MM-DD)
  vote_average: number           // Rating (0-10)
  vote_count: number             // Number of votes
  popularity: number             // Popularity score
  genre_ids: number[]            // Array of genre IDs
  original_language: string      // Language code
}
```

---

## 💬 Review Data Structure

```typescript
interface Review {
  id: string                     // Unique review ID
  author: string                 // Author name
  author_details: {
    name: string                 // Display name
    username: string             // Username
    avatar_path: string | null   // Avatar image path
    rating: number | null        // Personal rating (0-10)
  }
  content: string                // Full review text
  created_at: string             // Created timestamp
  updated_at: string             // Updated timestamp
  url: string                    // Review URL
}
```

---

## 🌈 Rating Color Codes

```typescript
8.0 - 10.0  →  Green (Excellent)
7.0 - 7.9   →  Blue (Great)
6.0 - 6.9   →  Yellow (Good)
5.0 - 5.9   →  Orange (Fair)
```

Apply to both:
- Movie average ratings
- Individual review ratings

---

## 📱 Responsive Breakpoints

```css
< 640px     →  2 columns  (Mobile)
≥ 640px     →  3 columns  (Large mobile)
≥ 768px     →  4 columns  (Tablet)
≥ 1024px    →  5 columns  (Desktop)
≥ 1280px    →  6 columns  (Large desktop)
```

---

## 🔑 TMDB API Configuration

```typescript
API_KEY: '8265bd1679663a7ea12ac168da84d2e8'
BASE_URL: 'https://api.themoviedb.org/3'
IMAGE_BASE: 'https://image.tmdb.org/t/p'
```

### Image Sizes
- `w200` - Small thumbnails
- `w500` - Medium images (default)
- `original` - Full resolution

---

## 🎯 Tabs & Their Data Sources

| Tab | Data Source | Filter |
|-----|-------------|--------|
| Recommended | Popular + Top Rated | rating ≥ 7.0, votes > 100 |
| Top Rated | /movie/top_rated | None |
| Popular | /movie/popular | None |
| Trending | /trending/movie/week | None |

---

## 🔍 Filter Logic Flow

1. **User changes filter** (genre/rating/sort)
2. **Triggers effect** in App.tsx
3. **Fetches new data** (if genre changed)
4. **Applies client-side filters** (rating threshold)
5. **Sorts results** (by selected option)
6. **Updates displayed movies**

---

## 🎨 Tailwind Classes Reference

### Common Patterns
```css
/* Card */
bg-gray-800/50 backdrop-blur-sm rounded-lg p-6

/* Button (Active) */
bg-gradient-to-r from-blue-500 to-purple-600 text-white

/* Button (Inactive) */
bg-gray-800 text-gray-300 hover:bg-gray-700

/* Rating Badge */
bg-green-500 text-white px-2 py-1 rounded-full text-xs

/* Modal Overlay */
bg-black/80 backdrop-blur-sm fixed inset-0 z-50

/* Text */
text-white (primary)
text-gray-400 (secondary)
text-gray-300 (content)
```

---

## ⚡ Performance Tips

### Optimize Images
```typescript
// Use appropriate size
getImageUrl(path, 'w200')  // For thumbnails
getImageUrl(path, 'w500')  // For cards
getImageUrl(path, 'original') // For backdrops
```

### Lazy Loading Reviews
```typescript
// Reviews only load when modal opens
useEffect(() => {
  if (movie) loadReviews()
}, [movie])
```

### Client-Side Filtering
```typescript
// Filter in browser (fast)
movies.filter(m => m.vote_average >= minRating)
```

---

## 🐛 Common Issues & Solutions

### Issue: Images not loading
```typescript
// Solution: Check fallback URLs
onError={(e) => {
  e.currentTarget.src = 'fallback-url'
}}
```

### Issue: API rate limiting
```typescript
// Solution: Use provided demo key
// Or get your own key at: themoviedb.org
```

### Issue: Reviews not showing
```typescript
// Check: Movie might have no reviews
// Empty state is handled automatically
```

---

## 🎯 Quick Testing Checklist

- [ ] Homepage loads with recommended movies
- [ ] Featured reviews appear (3 cards)
- [ ] Tabs switch (Recommended/Popular/Top Rated/Trending)
- [ ] Genre filter works
- [ ] Rating slider filters movies
- [ ] Sort options work
- [ ] Search finds movies
- [ ] Movie cards clickable
- [ ] Modal opens with correct data
- [ ] Overview tab shows movie details
- [ ] Reviews tab shows reviews (if available)
- [ ] Review text expands/collapses
- [ ] Modal closes properly
- [ ] Responsive on mobile
- [ ] All images load

---

## 📝 Code Snippets

### Add a new filter
```typescript
// 1. Add state
const [newFilter, setNewFilter] = useState(defaultValue)

// 2. Add to FilterBar props
<FilterBar
  newFilter={newFilter}
  onNewFilterChange={setNewFilter}
  // ... other props
/>

// 3. Use in applyFilters()
filtered = filtered.filter(movie => 
  // your filter logic
)
```

### Fetch additional data
```typescript
// Add to movieService.ts
export const fetchNewData = async () => {
  const response = await fetch(`${BASE_URL}/endpoint`)
  const data = await response.json()
  return data.results
}

// Use in App.tsx
const data = await fetchNewData()
```

---

## 🎓 Learning Resources

### React Concepts Used
- Functional components
- Hooks (useState, useEffect)
- Props and prop drilling
- Conditional rendering
- Event handling
- List rendering with map()

### TypeScript Features
- Interfaces
- Type annotations
- Optional properties (?)
- Union types (|)
- Array types (Movie[])

### Tailwind CSS
- Utility classes
- Responsive prefixes (md:, lg:)
- Hover states (hover:)
- Color opacity (/50)
- Gradients (from-, to-)

---

## 🔗 Useful Links

- TMDB API Docs: https://developers.themoviedb.org/3
- React Docs: https://react.dev
- TypeScript Docs: https://www.typescriptlang.org
- Tailwind CSS: https://tailwindcss.com
- Vite Docs: https://vitejs.dev

---

## 💡 Extension Ideas

1. Add user watchlist (localStorage)
2. Implement pagination
3. Add movie trailers
4. Show similar movies
5. Add cast information
6. Implement dark/light theme toggle
7. Add language filter
8. Show release year filter
9. Add runtime information
10. Create user profiles

---

## ✅ Best Practices Used

✅ TypeScript for type safety  
✅ Component composition  
✅ Single responsibility principle  
✅ Semantic HTML  
✅ Accessible buttons  
✅ Error handling  
✅ Loading states  
✅ Empty states  
✅ Image fallbacks  
✅ Responsive design  
✅ Clean code structure  
✅ Reusable components  

---

**Quick Reference Complete! Happy Coding! 🎬✨**
