# CineMatch - Movie Recommendation System

A modern, feature-rich movie recommendation system built with React, TypeScript, and Tailwind CSS. This application fetches real-time movie data from The Movie Database (TMDB) API and provides intelligent movie recommendations based on ratings, popularity, and user preferences.

## 🎬 Features

### Movie Data Scraping
- **Real-time API Integration**: Fetches movie data from The Movie Database (TMDB) API
- **Multiple Data Sources**: Combines data from popular movies, top-rated movies, and trending movies
- **Comprehensive Movie Information**: Displays title, overview, poster, backdrop, release date, ratings, and vote counts
- **User Reviews**: Fetches real user reviews from TMDB for each movie

### Recommendation System
- **Intelligent Recommendations**: Automatically recommends movies with ratings ≥ 7.0 and minimum vote count > 100
- **Top Rated Tab**: Shows the highest-rated movies across all genres
- **Trending Tab**: Displays currently trending movies
- **Popular Tab**: Shows the most popular movies right now

### Advanced Filtering & Sorting
- **Genre Filter**: Filter movies by specific genres (Action, Comedy, Drama, etc.)
- **Rating Slider**: Set minimum rating threshold (0-10)
- **Sort Options**: 
  - Highest Rated
  - Most Popular
  - Release Date

### Search Functionality
- Real-time movie search
- Search across all available movies
- Clear search to return to browsing

### User Interface
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Movie Cards**: Beautiful cards with posters, ratings, and metadata
- **Rating Badges**: Color-coded rating indicators (Excellent, Great, Good, Fair)
- **Recommendation Badges**: Highlights highly recommended movies (rating ≥ 8.0)
- **Modal Details**: Click any movie to see detailed information in a modal with tabs
- **Tabbed Interface**: Switch between Overview and Reviews within movie details
- **Smooth Animations**: Hover effects and transitions for better UX

### Review System
- **User Reviews Display**: Shows authentic user reviews from TMDB
- **Review Details**: Displays reviewer name, avatar, rating, and full review text
- **Review Ratings**: Each review shows the user's personal rating (if provided)
- **Read More/Less**: Expandable reviews for longer content
- **Featured Reviews Section**: Highlights top reviews from recommended movies
- **Review Count**: Shows total number of reviews for each movie
- **Review Timestamps**: Displays when reviews were posted and edited

### Rating System
- **Visual Star Ratings**: Color-coded star ratings
  - 🟢 Green (8.0+): Excellent
  - 🔵 Blue (7.0-7.9): Great
  - 🟡 Yellow (6.0-6.9): Good
  - 🟠 Orange (5.0-5.9): Fair
- **Vote Count Display**: Shows number of user votes
- **Popularity Score**: Displays movie popularity metrics

## 🚀 Technologies Used

- **React 18**: Modern React with hooks
- **TypeScript**: Type-safe code
- **Tailwind CSS**: Utility-first styling
- **Vite**: Fast build tool
- **TMDB API**: Real movie data source

## 📊 Data Sources

The application fetches data from:
1. **The Movie Database (TMDB) API**
   - Popular Movies endpoint
   - Top Rated Movies endpoint
   - Trending Movies endpoint
   - Genre List endpoint
   - Search endpoint
   - Discover endpoint (for genre-specific searches)
   - Movie Reviews endpoint (user-generated reviews)

## 🎯 Recommendation Algorithm

The recommendation system uses the following criteria:
- Minimum rating threshold: 7.0/10
- Minimum vote count: 100 (ensures reliable ratings)
- Combines top-rated and popular movies
- Sorts by rating in descending order
- Returns top 10 recommendations

## 🎨 UI Features

- **Dark Theme**: Modern dark interface optimized for movie browsing
- **Gradient Accents**: Beautiful gradients for buttons and badges
- **Image Optimization**: Multiple image sizes for performance
- **Loading States**: Spinner animations during data fetching
- **Empty States**: Helpful messages when no results found
- **Backdrop Blur**: Frosted glass effects for modern look

## 📱 Responsive Grid Layout

- Mobile (< 640px): 2 columns
- Small tablets (640px+): 3 columns
- Medium (768px+): 4 columns
- Large (1024px+): 5 columns
- Extra Large (1280px+): 6 columns

## 🔍 How to Use

1. **Browse Recommended Movies**: Default tab shows highly-rated movies
2. **Read Featured Reviews**: See what users are saying about top movies
3. **Switch Tabs**: Click on Popular, Top Rated, or Trending
4. **Filter by Genre**: Select a genre from the dropdown
5. **Adjust Rating**: Use the slider to set minimum rating
6. **Sort Results**: Choose how to sort movies
7. **Search**: Type in the search bar to find specific movies
8. **View Details**: Click any movie card to see full details
9. **Read Reviews**: Click the Reviews tab in the movie modal to read all user reviews
10. **Expand Reviews**: Click "Read More" to see full review text

## 🌟 Key Highlights

- ✅ Real-time movie data from TMDB API
- ✅ **User reviews scraping** from TMDB
- ✅ Smart recommendation algorithm
- ✅ Multiple filtering and sorting options
- ✅ Beautiful, responsive UI
- ✅ Detailed movie information
- ✅ Color-coded rating system
- ✅ **Featured reviews section** on homepage
- ✅ **Expandable reviews** with read more/less
- ✅ Search functionality
- ✅ Genre-based browsing
- ✅ Trending and popular movies
- ✅ **Tabbed movie details** (Overview & Reviews)
- ✅ Mobile-friendly design
- ✅ **Review author profiles** with avatars and usernames

## 📝 Notes

- Movie data is provided by The Movie Database (TMDB)
- Ratings are based on TMDB user votes
- All images are loaded from TMDB's CDN
- The application uses a public TMDB API key for demonstration

## 🔮 Future Enhancements

Possible future features:
- User accounts and watchlists
- Personalized recommendations based on viewing history
- Movie trailers
- Similar movies suggestions
- Multi-language support
- Advanced filters (year, runtime, etc.)
